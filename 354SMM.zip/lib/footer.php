<footer class="footer text-right">
                    2018 &copy; <?php echo $cfg_webname; ?> 
                </footer>

            </div>
            <!-- ============================================================== -->
            <!-- End Right content here -->
            <!-- ============================================================== -->


            <!-- Right Sidebar -->
            <div class="side-bar right-bar nicescroll">
                <h4 class="text-center">Chat</h4>
                <div class="contact-list nicescroll">
                    <ul class="list-group contacts-list">
                        <li class="list-group-item">
                            <a href="#">
                                <div class="avatar">
                                    <img src="<?php echo $cfg_baseurl; ?>assets/images/users/avatar-1.jpg" alt="">
                                </div>
                                <span class="name">Chadengle</span>
                                <i class="fa fa-circle online"></i>
                            </a>
                            <span class="clearfix"></span>
                        </li>
                        <li class="list-group-item">
                            <a href="#">
                                <div class="avatar">
                                    <img src="<?php echo $cfg_baseurl; ?>assets/images/users/avatar-2.jpg" alt="">
                                </div>
                                <span class="name">Tomaslau</span>
                                <i class="fa fa-circle online"></i>
                            </a>
                            <span class="clearfix"></span>
                        </li>
                        <li class="list-group-item">
                            <a href="#">
                                <div class="avatar">
                                    <img src="<?php echo $cfg_baseurl; ?>assets/images/users/avatar-3.jpg" alt="">
                                </div>
                                <span class="name">Stillnotdavid</span>
                                <i class="fa fa-circle online"></i>
                            </a>
                            <span class="clearfix"></span>
                        </li>
                        <li class="list-group-item">
                            <a href="#">
                                <div class="avatar">
                                    <img src="<?php echo $cfg_baseurl; ?>assets/images/users/avatar-4.jpg" alt="">
                                </div>
                                <span class="name">Kurafire</span>
                                <i class="fa fa-circle online"></i>
                            </a>
                            <span class="clearfix"></span>
                        </li>
                        <li class="list-group-item">
                            <a href="#">
                                <div class="avatar">
                                    <img src="<?php echo $cfg_baseurl; ?>assets/images/users/avatar-5.jpg" alt="">
                                </div>
                                <span class="name">Shahedk</span>
                                <i class="fa fa-circle away"></i>
                            </a>
                            <span class="clearfix"></span>
                        </li>
                        <li class="list-group-item">
                            <a href="#">
                                <div class="avatar">
                                    <img src="<?php echo $cfg_baseurl; ?>assets/images/users/avatar-6.jpg" alt="">
                                </div>
                                <span class="name">Adhamdannaway</span>
                                <i class="fa fa-circle away"></i>
                            </a>
                            <span class="clearfix"></span>
                        </li>
                        <li class="list-group-item">
                            <a href="#">
                                <div class="avatar">
                                    <img src="<?php echo $cfg_baseurl; ?>assets/images/users/avatar-7.jpg" alt="">
                                </div>
                                <span class="name">Ok</span>
                                <i class="fa fa-circle away"></i>
                            </a>
                            <span class="clearfix"></span>
                        </li>
                        <li class="list-group-item">
                            <a href="#">
                                <div class="avatar">
                                    <img src="<?php echo $cfg_baseurl; ?>assets/images/users/avatar-8.jpg" alt="">
                                </div>
                                <span class="name">Arashasghari</span>
                                <i class="fa fa-circle offline"></i>
                            </a>
                            <span class="clearfix"></span>
                        </li>
                        <li class="list-group-item">
                            <a href="#">
                                <div class="avatar">
                                    <img src="<?php echo $cfg_baseurl; ?>assets/images/users/avatar-9.jpg" alt="">
                                </div>
                                <span class="name">Joshaustin</span>
                                <i class="fa fa-circle offline"></i>
                            </a>
                            <span class="clearfix"></span>
                        </li>
                        <li class="list-group-item">
                            <a href="#">
                                <div class="avatar">
                                    <img src="<?php echo $cfg_baseurl; ?>assets/images/users/avatar-10.jpg" alt="">
                                </div>
                                <span class="name">Sortino</span>
                                <i class="fa fa-circle offline"></i>
                            </a>
                            <span class="clearfix"></span>
                        </li>
                    </ul>  
                </div>
            </div>
            <!-- /Right-bar -->

        </div>
        <!-- END wrapper -->


    
        <script>
            var resizefunc = [];
        </script>

        <!-- jQuery  -->
        <script src="<?php echo $cfg_baseurl; ?>assets/js/jquery.min.js"></script>
        <script src="<?php echo $cfg_baseurl; ?>assets/js/bootstrap.min.js"></script>
        <script src="<?php echo $cfg_baseurl; ?>assets/js/detect.js"></script>
        <script src="<?php echo $cfg_baseurl; ?>assets/js/fastclick.js"></script>
        <script src="<?php echo $cfg_baseurl; ?>assets/js/jquery.slimscroll.js"></script>
        <script src="<?php echo $cfg_baseurl; ?>assets/js/jquery.blockUI.js"></script>
        <script src="<?php echo $cfg_baseurl; ?>assets/js/waves.js"></script>
        <script src="<?php echo $cfg_baseurl; ?>assets/js/wow.min.js"></script>
        <script src="<?php echo $cfg_baseurl; ?>assets/js/jquery.nicescroll.js"></script>
        <script src="<?php echo $cfg_baseurl; ?>assets/js/jquery.scrollTo.min.js"></script>

        <script src="<?php echo $cfg_baseurl; ?>assets/js/jquery.app.js"></script>
        
        <!-- jQuery  -->
        <script src="<?php echo $cfg_baseurl; ?>assets/plugins/moment/moment.js"></script>
        
        <!-- jQuery  -->
        <script src="<?php echo $cfg_baseurl; ?>assets/plugins/waypoints/lib/jquery.waypoints.js"></script>
        <script src="<?php echo $cfg_baseurl; ?>assets/plugins/counterup/jquery.counterup.min.js"></script>
        
        <!-- jQuery  -->
        <script src="<?php echo $cfg_baseurl; ?>assets/plugins/sweetalert/dist/sweetalert.min.js"></script>
        

        <!-- jQuery  -->
        <script src="<?php echo $cfg_baseurl; ?>assets/pages/jquery.todo.js"></script>
        
        <!-- jQuery  -->
        <script src="<?php echo $cfg_baseurl; ?>assets/pages/jquery.chat.js"></script>
        
        <!--Morris Chart-->
        <script src="<?php echo $cfg_baseurl; ?>assets/plugins/raphael/raphael-min.js"></script>
        <script src="<?php echo $cfg_baseurl; ?>assets/plugins/morris.js/morris.min.js"></script>
        
        <!-- jQuery  -->
        <script src="<?php echo $cfg_baseurl; ?>assets/pages/jquery.dashboard.js"></script>
        
        <script type="text/javascript">
            /* ==============================================
            Counter Up
            =============================================== */
            jQuery(document).ready(function($) {
                $('.counter').counterUp({
                    delay: 100,
                    time: 1200
                });
            });
        </script>

    
    </body>

<!-- Mirrored from moltran.coderthemes.com/purple/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 13 Jun 2018 02:57:30 GMT -->
</html>